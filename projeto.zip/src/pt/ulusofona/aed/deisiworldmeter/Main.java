package pt.ulusofona.aed.deisiworldmeter;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static ArrayList<Pais> paises = new ArrayList<>();
    static ArrayList<Cidade> cidades = new ArrayList<>();
    static ArrayList<InputInvalido> inputInvalido = new ArrayList<>();

    public static ArrayList getObjects(TipoEntidade tipo) {
        if (tipo == TipoEntidade.PAIS) {
            return paises;
        }
        if (tipo == TipoEntidade.CIDADE) {
            return cidades;
        }
        if (tipo == TipoEntidade.INPUT_INVALIDO) {
            return inputInvalido;
        }
        return null;
    }


    public static boolean parseFiles(File folder) {
        paises = new ArrayList<>();// evita duplicados
        cidades = new ArrayList<>();
        inputInvalido = new ArrayList<>();


        String[] nomesFicheiros = {"paises.csv", "cidades.csv"};   // leitura de ficheiros
        for (String nome : nomesFicheiros) {
            File ficheiro = new File(folder, nome);
            if (!ficheiro.exists() || ficheiro.isDirectory()) {
                System.out.println("Erro: O ficheiro " + nome + " não existe ou não é um ficheiro válido.");
                return false;
            }
        }
        lerPaises(new File(folder, "paises.csv"));
        lerCidades(new File(folder, "cidades.csv"));

        return true;
    }


    static boolean lerPaises(File ficheiroPaises) {
        Scanner scanner = null;
        InputInvalido inputInvalidoPaises = new InputInvalido(ficheiroPaises.getName());
        boolean primeiraLinha = true; // Ignora a primeira linha (cabeçalho)
        int numeroDaLinha = 0; // Contador para o número da linha

        try {
            scanner = new Scanner(ficheiroPaises);
        } catch (FileNotFoundException e) {
            return false;
        }

        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            numeroDaLinha++;

            if (primeiraLinha) {
                primeiraLinha = false;
                continue;
            }

            String[] partes = linha.split(",");
            if (partes.length == 4) {
                try {
                    int id = Integer.parseInt(partes[0]);
                    String alfa2 = partes[1];
                    String alfa3 = partes[2];
                    String nome = partes[3];

                    // Verifica se o ID já existe na lista de países (paises repetidos)
                    boolean idIgual = false;
                    for (Pais paisExistente : paises) {
                        if (paisExistente.id == id) {
                            idIgual = true;
                            break;
                        }
                    }

                    if (!idIgual) {
                        if (id > 0 && alfa2.length() == 2 && alfa3.length() == 3 && !nome.isEmpty()) {
                            Pais pais = new Pais(id, alfa2, alfa3, nome);
                            paises.add(pais);
                            inputInvalidoPaises.contalinhascorretas();
                        } else {
                            inputInvalidoPaises.contalinhasIncorretas(numeroDaLinha);
                        }
                    } else {
                        inputInvalidoPaises.contalinhasIncorretas(numeroDaLinha);
                    }

                } catch (NumberFormatException e) {
                    inputInvalidoPaises.contalinhasIncorretas(numeroDaLinha);
                }
            } else {
                inputInvalidoPaises.contalinhasIncorretas(numeroDaLinha);
            }
        }
        scanner.close();
        inputInvalido.add(inputInvalidoPaises);
        return true;
    }

    static boolean lerCidades(File ficheiroCidades) {
        Scanner scanner = null;
        InputInvalido inputInvalidoCidades = new InputInvalido(ficheiroCidades.getName());
        boolean primeiraLinha = true; // Ignora a primeira linha (cabeçalho)
        int numeroDaLinha = 0; // Contador para o número da linha

        try {
            scanner = new Scanner(ficheiroCidades);
        } catch (FileNotFoundException e) {
            return false;
        }

        while (scanner.hasNext()) {
            String linha = scanner.nextLine();
            numeroDaLinha++;

            if (primeiraLinha) {
                primeiraLinha = false;
                continue;
            }

            String[] partes = linha.split(",");   // le os compeonentes apesar das , nos ficheiros
            if (partes.length == 6) {
                try {
                    String alfa2 = partes[0];
                    String nomeCidade = partes[1];
                    int regiao = Integer.parseInt(partes[2]);
                    double populacao = Double.parseDouble(partes[3]);
                    double latitude = Double.parseDouble(partes[4]);
                    double longitude = Double.parseDouble(partes[5]);

                    if (alfa2.length() == 2 && !(regiao > 0) && populacao > 0) {

                        boolean paisEncontrado = false;
                        for (Pais pais : paises) { // Trocar por HashMap
                            if (pais.alfa2.equalsIgnoreCase(alfa2)) {
                                paisEncontrado = true;
                                break;
                            }
                        }

                        if (paisEncontrado) {
                            Cidade cidadeEnc = new Cidade(alfa2, nomeCidade, regiao, populacao, latitude, longitude);
                            cidades.add(cidadeEnc);
                            inputInvalidoCidades.contalinhascorretas();

                        } else {
                            inputInvalidoCidades.contalinhasIncorretas(numeroDaLinha);
                        }
                    } else {
                        inputInvalidoCidades.contalinhasIncorretas(numeroDaLinha);
                    }
                } catch (NumberFormatException e) {
                    inputInvalidoCidades.contalinhasIncorretas(numeroDaLinha);
                }
            } else {
                inputInvalidoCidades.contalinhasIncorretas(numeroDaLinha);
            }
        }
        scanner.close();
        inputInvalido.add(inputInvalidoCidades);
        return true;
    }



    public static void main(String[] args)  {
        System.out.println("Bem-vindo ao DEISI World Meter");

        long start = System.currentTimeMillis();
        boolean parseOk = parseFiles(new File("test-files"));

        if (!parseOk) {
            System.out.println("Erro na leitura dos ficheiros");
            return;
        }
        System.out.println("Leitura concluída");
        long end = System.currentTimeMillis();
        System.out.println("Ficheiros lidos com sucesso em " + (end-start) + "ms" );
        System.out.println();

        System.out.println("TESTAR PAISES");
        System.out.println(paises);
        ArrayList paisesLidos = getObjects(TipoEntidade.PAIS);
        System.out.println("Teste 1: Quantidade paises no ficheiro");
        System.out.println("Total paises: " + paisesLidos.size());
        System.out.println();

        System.out.println("TESTAR CIDADES");
        System.out.println(cidades);
        ArrayList cidadesLidas = getObjects(TipoEntidade.CIDADE);
        System.out.println("Teste 2: Quantidade de cidades no ficheiro");
        System.out.println("Total cidades: " + cidadesLidas.size());
        System.out.println();


        System.out.println("Teste 2: Ver primeiros 3 paises");
        for (int i = 0; i < 3 && i < paisesLidos.size(); i++) { // vê os primeiros 3
            System.out.println(paisesLidos.get(i));
        }
        System.out.println();

        System.out.println("Teste 3: Ver últimos 5 paises do ficheiro");
        for (int i = paisesLidos.size() - 2; i<paisesLidos.size(); i++) { // vê os primeiros 3
            System.out.println(paisesLidos.get(i));
        }
        //TESTE 4 : Teste de erro":
            // Cria uma linha inválida no CSV:
            // é suposto o programa nao falhar, e a linha ser ignorada ex: 123,PT

        System.out.println();
        System.out.println("Informações sobre a leitura de ficheiros:");
        System.out.println("nome | linhas OK | linhas NOK | primeira linha NOK");
        ArrayList inputsInvalidos = getObjects(TipoEntidade.INPUT_INVALIDO);
        System.out.println(inputsInvalidos.get(0));

    }
}

